
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let drone = { x: 50, y: 200, width: 40, height: 20, dy: 0 };
let obstacles = [
    { x: 300, y: 0, width: 20, height: 150 },
    { x: 500, y: 250, width: 20, height: 150 },
    { x: 700, y: 0, width: 20, height: 120 }
];
let keys = {};
let gravity = 0.5;
let gameOver = false;
let gameWon = false;

document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

function update() {
    if (gameOver || gameWon) return;
    drone.dy += gravity;
    if (keys['ArrowUp']) drone.dy = -6;
    drone.y += drone.dy;

    // Move obstacles left
    obstacles.forEach(obs => obs.x -= 2);

    // Check collisions
    for (let obs of obstacles) {
        if (drone.x < obs.x + obs.width &&
            drone.x + drone.width > obs.x &&
            drone.y < obs.y + obs.height &&
            drone.y + drone.height > obs.y) {
            document.getElementById('gameOver').style.display = 'block';
            gameOver = true;
            return;
        }
    }

    // Win condition
    if (obstacles[obstacles.length - 1].x < 0) {
        document.getElementById('winMessage').style.display = 'block';
        sessionStorage.setItem('freePlay', 'true');
        gameWon = true;
        return;
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw drone
    ctx.fillStyle = 'red';
    ctx.fillRect(drone.x, drone.y, drone.width, drone.height);

    // Draw obstacles
    ctx.fillStyle = 'green';
    obstacles.forEach(obs => {
        ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
    });
}

function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
}

loop();
